/* Keep this header for compatibility with external code, it's currently not
	used anywhere in the core and there are no implementations in TSRM. */
#include "win32/readdir.h"
